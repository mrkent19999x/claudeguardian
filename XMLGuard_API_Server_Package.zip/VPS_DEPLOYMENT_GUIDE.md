# 🚀 HƯỚNG DẪN DEPLOYMENT VPS API SERVER

## 📋 TỔNG QUAN

Em đã tạo **Custom API Endpoints** cho server VPS để XML Guard có thể kết nối và hoạt động đầy đủ.

## 🔧 CÁC FILE ĐÃ TẠO

### 1. `xmlguard_api_server.py` - API Server chính
- Chạy trên port 8080 (khác với MeshCentral port 4433)
- Cung cấp 4 API endpoints chính
- Xử lý JSON requests/responses

### 2. `deploy_api_server.bat` - Script deployment
- Tự động cài đặt dependencies
- Khởi động API server
- Kiểm tra Python installation

## 🌐 API ENDPOINTS

### ✅ `/api/status` (GET)
- Kiểm tra trạng thái server
- Trả về thông tin API version
- Test: `https://103.69.86.130:8080/api/status`

### ✅ `/api/heartbeat` (POST)
- Nhận heartbeat từ XML Guard clients
- Xác nhận client đang hoạt động
- Test: `https://103.69.86.130:8080/api/heartbeat`

### ✅ `/api/legitimate_files` (POST)
- Tìm file gốc hợp lệ dựa trên 4 trường định danh
- Trả về đường dẫn file gốc
- Test: `https://103.69.86.130:8080/api/legitimate_files`

### ✅ `/api/xmlguard` (POST)
- API chuyên dụng cho XML Guard
- Đăng ký client, lấy config
- Test: `https://103.69.86.130:8080/api/xmlguard`

## 📋 BƯỚC DEPLOYMENT

### Bước 1: Upload file lên VPS
```bash
# Upload xmlguard_api_server.py lên VPS server
scp xmlguard_api_server.py root@103.69.86.130:/root/
```

### Bước 2: Cài đặt trên VPS
```bash
# SSH vào VPS
ssh root@103.69.86.130

# Cài đặt Python dependencies
pip install requests urllib3

# Tạo thư mục cho file gốc
mkdir -p /root/TaxFiles/Legitimate/
```

### Bước 3: Khởi động API Server
```bash
# Chạy API server
python xmlguard_api_server.py

# Hoặc chạy background
nohup python xmlguard_api_server.py > api_server.log 2>&1 &
```

### Bước 4: Kiểm tra hoạt động
```bash
# Test API endpoints
curl https://103.69.86.130:8080/api/status
curl -X POST https://103.69.86.130:8080/api/heartbeat -H "Content-Type: application/json" -d '{"client_id":"test","version":"3.0.0"}'
```

## 🔧 CẤU HÌNH XML GUARD

XML Guard đã được cập nhật để kết nối với API server mới:

```json
{
  "MeshCentral": {
    "Enabled": true,
    "ServerUrl": "https://103.69.86.130:8080",
    "PingInterval": 60,
    "Timeout": 10
  }
}
```

## 🎯 TEST THỰC TẾ

### Test 1: Kiểm tra API Server
```bash
curl https://103.69.86.130:8080/api/status
```

**Kết quả mong đợi:**
```json
{
  "success": true,
  "server_status": "online",
  "xmlguard_enabled": true,
  "api_version": "1.0.0",
  "timestamp": "2025-09-07T18:00:00.000000",
  "endpoints": ["/api/heartbeat", "/api/legitimate_files", "/api/status", "/api/xmlguard"]
}
```

### Test 2: Test Heartbeat
```bash
curl -X POST https://103.69.86.130:8080/api/heartbeat \
  -H "Content-Type: application/json" \
  -d '{"client_id":"TEST_CLIENT","status":"testing","version":"3.0.0"}'
```

**Kết quả mong đợi:**
```json
{
  "success": true,
  "message": "Heartbeat received",
  "timestamp": "2025-09-07T18:00:00.000000",
  "server_status": "online",
  "client_id": "TEST_CLIENT",
  "version": "3.0.0"
}
```

### Test 3: Test Legitimate Files
```bash
curl -X POST https://103.69.86.130:8080/api/legitimate_files \
  -H "Content-Type: application/json" \
  -d '{"mst":"0401985971","form_code":"842","period":"2/2025","action":"get_legitimate_path"}'
```

**Kết quả mong đợi:**
```json
{
  "success": true,
  "file_path": "C:/TaxFiles/Legitimate/ETAX0401985971_842_2_2025.xml",
  "mst": "0401985971",
  "form_code": "842",
  "period": "2/2025",
  "timestamp": "2025-09-07T18:00:00.000000"
}
```

## 🚀 DEPLOYMENT HOÀN TẤT

Sau khi deploy thành công:

1. ✅ **API Server** chạy trên port 8080
2. ✅ **XML Guard** kết nối với API server
3. ✅ **Heartbeat** hoạt động mỗi 60 giây
4. ✅ **File protection** sử dụng API server
5. ✅ **Remote monitoring** qua VPS

## 📞 HỖ TRỢ

Nếu gặp vấn đề:
- Kiểm tra firewall port 8080
- Kiểm tra Python installation trên VPS
- Kiểm tra SSL certificate
- Xem log: `tail -f api_server.log`

---

**🎉 VPS API SERVER SẴN SÀNG DEPLOYMENT!**
